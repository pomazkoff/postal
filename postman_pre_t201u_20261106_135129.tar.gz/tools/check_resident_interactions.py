#!/usr/bin/env python3
"""Linux-friendly data/source regression checks, NOT an iOS runtime/UI test.

Run: python3 tools/check_resident_interactions.py
The selection fixtures exercise the story data; source contracts guard the Swift wiring.
See docs/RESIDENT_TAP.md for the required device/simulator smoke test.
"""
import json
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
ENGINE = (ROOT / "Postman/App/ChapterEngine.swift").read_text()
SCENE = (ROOT / "Postman/Scene/WorldScene.swift").read_text()
GAME = (ROOT / "Postman/App/GameModel.swift").read_text()
HUD = (ROOT / "Postman/UI/HUDView.swift").read_text()
CARDS = (ROOT / "Postman/UI/StoryCards.swift").read_text()
STORIES = [json.loads((ROOT / f"Postman/GameAssets/Data/chapter{n}_story.json").read_text())
           for n in (1, 2)]


def body(source, signature):
    start = source.index("{", source.index(signature))
    depth = 1
    end = start + 1
    while depth:
        depth += (source[end] == "{") - (source[end] == "}")
        end += 1
    return source[start + 1:end - 1]


def available_choice(story, resident, done=(), flags=()):
    """Data-only fixture oracle; resident choices currently use flag requirements."""
    def requirements_met(event):
        for atom in event.get("requires", "").split(","):
            if not atom:
                continue
            negative = atom.startswith("!")
            kind, value = atom.lstrip("!").split(":", 1)
            assert kind == "flag", "Extend fixture oracle if story conditions change"
            if (value in flags) == negative:
                return False
        return True
    events = sorted(story["events"], key=lambda e: e["step"])
    return next((e for e in events if e.get("resident") == resident and e["type"] == "choice"
                 and e["id"] not in done and requirements_met(e) and e.get("options")), None)


class StoryDataTests(unittest.TestCase):
    def test_all_animal_choices_have_renderable_resident_ids(self):
        count = 0
        for story in STORIES:
            residents = {r["id"] for r in story["residents"]}
            for event in story["events"]:
                if event["id"].startswith("e_animal_") and event["type"] == "choice":
                    count += 1
                    self.assertIn(event["resident"], residents)
                    self.assertTrue(event["options"])
        self.assertEqual(count, 7)

    def test_matrena_branches_and_once_fixtures(self):
        story = STORIES[0]
        self.assertEqual(available_choice(story, "matrena")["id"], "e_animal_matrena")
        self.assertEqual(available_choice(story, "matrena", flags={"ramka"})["id"],
                         "e_animal_matrena_jealous")
        self.assertIsNone(available_choice(story, "matrena", done={"e_animal_matrena"}))
        self.assertIsNone(available_choice(story, "matrena", flags={"ramka"},
                                          done={"e_animal_matrena_jealous"}))

    def test_reward_choices_become_replay_not_another_reward(self):
        for story, resident, event_id in [(STORIES[0], "cat_barrel", "e_animal_cat"),
                                           (STORIES[1], "raven_saddle", "e_animal_raven"),
                                           (STORIES[1], "dog_penki", "e_animal_dog")]:
            self.assertEqual(available_choice(story, resident)["id"], event_id)
            self.assertIsNone(available_choice(story, resident, done={event_id}))


class SwiftContractTests(unittest.TestCase):
    def test_tap_selects_any_resident_choice_without_step_gate(self):
        code = body(ENGINE, "func interactWithResident(")
        self.assertIn("$0.resident == residentID", code)
        self.assertIn("$0.type == .choice", code)
        self.assertIn("!state.doneEvents.contains($0.id) && check($0.requires)", code)
        self.assertNotIn("e_animal_", code)
        self.assertNotIn(".step <=", code)
        self.assertNotIn(".step >=", code)

    def test_tap_has_no_story_effects_and_preserves_queue(self):
        code = body(ENGINE, "func interactWithResident(")
        for forbidden in ("applyChoice(", "apply(", "flags.insert", "addTrust(", "state.items[",
                          "doneEvents.insert", "state.choices[", "beat(", "log("):
            # state.choices is read, never assigned, when finding the previous result.
            if forbidden == "state.choices[":
                self.assertNotIn("state.choices[event.id] =", code)
            else:
                self.assertNotIn(forbidden, code)
        self.assertIn("state.pendingCards.removeAll { $0.id == interaction.id }", code)
        self.assertIn("state.pendingCards.insert(interaction, at: 0)", code)
        self.assertNotIn("pendingCards =", code)

    def test_repeat_is_read_only_scene_with_conditioned_completed_lines(self):
        code = body(ENGINE, "func interactWithResident(")
        self.assertIn("events.reversed().filter { state.doneEvents.contains($0.id) }", code)
        self.assertIn("first { check($0.if) }", code)
        self.assertIn('id: "resident:" + residentID, kind: .scene', code)
        self.assertIn("?.result", code)
        self.assertIn("Пока тихо", code)

    def test_only_presented_choice_can_resolve_before_step_and_only_once(self):
        code = body(ENGINE, "func resolveChoice(")
        self.assertIn("!state.doneEvents.contains(eventID)", code)
        self.assertIn("event.step <= currentStep || state.pendingCards.contains", code)
        self.assertIn("$0.id == eventID && $0.kind == .choice", code)
        self.assertIn("guard check(event.requires)", code)
        self.assertEqual(code.count("applyChoice(event, option, by: chooser)"), 1)
        apply = body(ENGINE, "private func applyChoice(")
        self.assertIn("state.doneEvents.insert(event.id)", apply)
        self.assertIn("state.pendingCards.removeAll { $0.id == event.id }", apply)

    def test_invalidated_early_choice_does_not_stick(self):
        tap = body(ENGINE, "func interactWithResident(")
        self.assertIn("!check(event.requires)", tap)
        self.assertIn("$0.id == event.id && $0.kind == .choice", tap)
        resolve = body(ENGINE, "func resolveChoice(")
        self.assertIn("state.pendingCards.removeAll { $0.id == eventID }", resolve)
        process = body(ENGINE, "private func process()")
        self.assertIn("state.pendingCards.removeAll { $0.id == event.id }", process)

    def test_step_auto_entry_stays_intact(self):
        code = body(ENGINE, "private func process()")
        self.assertIn("guard stop.step <= currentStep else { break }", code)
        self.assertIn("guard shouldAutoResolve(after: index, step: event.step)", code)
        self.assertIn("let option = defaultOption(event)", code)
        self.assertIn("applyChoice(event, option, by: .postman)", code)

    def test_tap_defers_to_pan_and_pinch_and_is_removed_with_view(self):
        install = body(SCENE, "override func didMove(to view:")
        for fragment in ("tap.cancelsTouchesInView = false", "tap.require(toFail: pan)",
                         "tap.require(toFail: pinch)", "view.addGestureRecognizer(tap)"):
            self.assertIn(fragment, install)
        self.assertIn("view.removeGestureRecognizer(tap)", body(SCENE, "override func willMove(from view:"))
        self.assertNotIn("override func touches", SCENE)
        simultaneous = body(SCENE, "shouldRecognizeSimultaneouslyWith")
        self.assertIn("[panRecognizer, pinchRecognizer]", simultaneous)

    def test_hit_test_is_sprite_local_not_whole_screen(self):
        code = body(SCENE, "private func residentKey(at")
        self.assertIn("nodes(at: point)", code)
        self.assertIn("node.contains(convert(point, to: parent))", code)
        self.assertIn("residentNodes[key] === node || companionNode === node", code)
        receive = body(SCENE, "shouldReceive touch:")
        self.assertIn("isUserInteractionEnabled", receive)
        self.assertIn("residentKey(at: convertPoint(fromView:", receive)
        handle = body(SCENE, "private func handleResidentTap(")
        self.assertIn("g.state == .ended, !isPanning", handle)
        self.assertIn("onResidentTap?(chapterID, parts[1])", handle)

    def test_chapter_context_never_switches_progress_or_duplicates_active_writer(self):
        code = body(GAME, "private func visitResident(")
        self.assertIn("if chapterID == self.chapter.id", code)
        self.assertIn("visitEngine = engine", code)
        self.assertIn(r'chapter\(chapterID)_state.json', code)
        for fragment in ("switchToChapter(", "syncEngine(", "addDebugSteps(", "update(chapterSteps:"):
            self.assertNotIn(fragment, code)
        self.assertIn(".environmentObject(visit.engine)", HUD)
        self.assertIn("StoryCardView(card: card, chapter: visit.chapter)", HUD)
        self.assertIn("chapter ?? game.chapter", CARDS)
        self.assertIn("ResidentLibrary.figure(for: resident, assetsFolder: assetsFolder)", CARDS)


if __name__ == "__main__":
    unittest.main(verbosity=2)
